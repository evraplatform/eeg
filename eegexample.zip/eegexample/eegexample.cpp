// eegexample.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//
#define EEGO_SDK_BIND_STATIC
//#define TRACE_EEG // Si TRACE_EEG est défini, le programme utilisera les données EEG. SInon, il utilisera les données Impédance
//#define DEBUG // Si DEBUG est défini, affichage surl'écran des données de trace.

#include <stdio.h>
#include <eemagine/sdk/factory.h>
#include <eemagine/sdk/wrapper.cc>
#include<chrono>
#include <thread>
#include <time.h>

#include <iostream>
#include <conio.h>

using namespace eemagine::sdk;
typedef std::chrono::high_resolution_clock Time;
typedef std::chrono::milliseconds ms;
typedef std::chrono::duration<float> fsec;

#define FREQ500 500
#define FREQ512 512
#define FREQ1000 1000
#define FREQ1024 1024
#define FREQ2000 2000
#define FREQ2048 2048
#define FREQ4000 4000
#define FREQ4096 4096
#define FREQ8000 8000
#define FREQ8192 8192
#define FREQ16000 16000  // Donne des résultats incohérents
#define FREQ16384 16384  // Donne des résultats incohérents

#define NB_CHANNELS_EEG_TAKE_INTO_ACCOUNT 34 // Nombre de canaux EEG tracés
#define NB_CHANNELS_IMP_TAKE_INTO_ACCOUNT 8 // Nombre de canaux Impédance tracés

// Calcul de temps depuis le temps t0, en secondes
float delay(std::chrono::steady_clock::time_point t0)
{
    auto t1 = Time::now();
    fsec fs = t1 - t0;
    return fs.count();
}

int main()
{
    using namespace eemagine::sdk;
    factory fact;
    int nbChannelsVolt;
    int nbChannelsImp;
    int indexSample;
    int sampleCount;
    float delta_t;
    int frequency = FREQ500; // Fréquence testée
    FILE* f;

    try {
        amplifier* amp = fact.getAmplifier();
        std::cout << "Serial number: " << amp->getSerialNumber() << "\n";
#ifdef TRACE_EEG // Compilation du code pour mesurer les signaux EEG
        std::cout << "Trying to open Eeg Stream, frequency requested (Hz): " << frequency << "..." << "\n";
        stream* voltstream = amp->OpenEegStream(frequency); // Ouverture du streaming EEG (Volt) avec une fréquence de frequency
        std::cout << " DONE!\n";
        f = fopen("volt.txt", "w");
        buffer voltbuf = voltstream->getData(); // On récupère les données du streaming EEG dans voltbuf ...
        nbChannelsVolt = voltbuf.getChannelCount(); // ... et on détermine le nombre de canaux sur ce streaming
        printf("Channel Count (Volt): %d\n", nbChannelsVolt);
#else // Compilation du code pour mesurer l'impédance
        std::cout << "Trying to open Impedance Stream ..." << "\n";
        stream* impstream = amp->OpenImpedanceStream( ); // Ouverture du streaming Impédance (Ohm)
        std::cout << " DONE!\n";
        f = fopen("imp.txt", "w");
        buffer impbuf = impstream->getData(); // On récupère les données du streaming Impédance dans impbuf ...
        nbChannelsImp = impbuf.getChannelCount(); //... et on détermine le nombre de canaux sur ce streaming
        printf("Channel Count (Ohm): %d\n", nbChannelsImp);
#endif TRACE_EEG
       
        unsigned long frame = 0;
        auto t0 = Time::now(); // Temps t0 du début de l'expérience
        while ((!_kbhit()) && ((delta_t = delay(t0)) < 60.0F)) // Tant qu'on n'a pas appuyé sune touche ou que l'expérience n'a pas duré plus de 60 secondes,
        {
#ifdef TRACE_EEG
            voltbuf = voltstream->getData(); // On récupère les données du streaming EEG dans impbuf ...
            sampleCount = voltbuf.getSampleCount(); // ... et on détermine le nombre d'exemples contenus dans le buffer de l'ampli
#ifdef DEBUG
            printf("Channel Count (Volt): %d\n", voltbuf.getChannelCount());
            printf("Sample count: %d\n", sampleCount);
#endif  DEBUG
            double volt;
#ifdef DEBUG
            printf("%u %1.3f 1", frame, delta_t);
#endif DEBUG
            for (int sc = 0; sc < sampleCount; sc++) // Boucle sur ous les exemples contenus dans le buffer de l'ampli
            {
                delta_t = delay(t0); // Temps depuis le début de l'expérience
                fprintf(f, "%u %1.3f 1", frame, delta_t);
                for (int i = 0; i < NB_CHANNELS_EEG_TAKE_INTO_ACCOUNT; i++) // Boucle sur les NB_CHANNELS_EEG_TAKE_INTO_ACCOUNT premiers canaux
                {
                    volt = voltbuf.getSample(i, sc); // On lit les données EEG du canal i de l'exemple sc
#ifdef DEBUG
                    printf(" %lf", volt);
#endif DEBUG
                    fprintf(f, " %lf", volt);
                }
#ifdef DEBUG
                printf("\n");
#endif DEBUG
                fprintf(f, "\n");
                frame++;
            }
#else
            impbuf = impstream->getData(); // On récupère les données du streaming Impédance dans impbuf ...
            sampleCount = impbuf.getSampleCount(); // ... et on détermine le nombre d'exemples contenus dans le buffer de l'ampli
#ifdef DEBUG
            printf("Channel Count (Ohm): %d\n", impbuf.getChannelCount());
            printf("Sample count: %d\n", sampleCount);
#endif  DEBUG
            double imp;
#ifdef DEBUG
            printf("%u %1.3f 1", frame, delta_t);
#endif DEBUG
            for (int sc = 0; sc < sampleCount; sc++) // Boucle sur ous les exemples contenus dans le buffer de l'ampli
            {
                delta_t = delay(t0); // Temps depuis le début de l'expérience
                fprintf(f, "%u %1.3f 1", frame, delta_t);
                for (int i = 0; i < NB_CHANNELS_IMP_TAKE_INTO_ACCOUNT; i++) // Boucle sur les NB_CHANNELS_IMP_TAKE_INTO_ACCOUNT premiers canaux
                {
                    imp = impbuf.getSample(i, sc); // On lit les données Impédance du canal i de l'exemple sc
#ifdef DEBUG
                    printf(" %lf", imp);
#endif DEBUG
                    fprintf(f, " %lf", imp);
                }
#ifdef DEBUG
                printf("\n");
#endif DEBUG
                fprintf(f, "\n");
                frame++;
            }

#endif TRACE_EEG
        } // Fin de la boucle While ...
        fclose(f);
#ifdef TRACE_EEG
        delete(voltstream);
#else
        delete(impstream);
#endif
        delete(amp);
    }
    catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return -1;
    }
  
   return 0;
}

